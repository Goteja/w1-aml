// SPDX-License-Identifier: GPL-2.0
#include <linux/init.h>
#include <linux/module.h>
#include <linux/of.h>

#include "overlay_blob.h"

static int overlay_id;

static int __init tanix_bt_uart_init(void)
{
    int ret;

    if (!of_machine_is_compatible("tanixw2"))
        return -ENODEV;
    ret = of_overlay_fdt_apply(overlay_blob, sizeof(overlay_blob),
                               &overlay_id, NULL);
    if (ret && overlay_id)
        of_overlay_remove(&overlay_id);
    return ret;
}

static void __exit tanix_bt_uart_exit(void)
{
    int ret = of_overlay_remove(&overlay_id);

    if (ret)
        pr_err("Tanix Bluetooth UART overlay removal failed: %d\n", ret);
}

module_init(tanix_bt_uart_init);
module_exit(tanix_bt_uart_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Temporary Tanix W2 Bluetooth UART_A device tree overlay");
