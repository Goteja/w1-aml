// SPDX-License-Identifier: GPL-2.0
#include <linux/clk.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/of.h>

#include "overlay_blob.h"

static bool cap_pwm;
module_param(cap_pwm, bool, 0444);
MODULE_PARM_DESC(cap_pwm, "Cap PWM_E at 24 MHz and hold the SDIO reference clock");

static bool apply_delay = true;
module_param(apply_delay, bool, 0444);
MODULE_PARM_DESC(apply_delay, "Apply the diagnostic SDIO startup delay");

static int overlay_id;
static struct clk *pwm_input;
static struct clk *sdio_ref;

static void stop_reference_clock(void)
{
    if (sdio_ref) {
        clk_disable_unprepare(sdio_ref);
        clk_put(sdio_ref);
    }
    if (pwm_input)
        clk_put(pwm_input);
}

static int start_reference_clock(void)
{
    struct device_node *node;
    struct clk *clk;
    int ret;

    node = of_find_node_by_path("/soc/bus@fe000000/pwm@5c000");
    if (!node)
        return -ENODEV;
    clk = of_clk_get(node, 0);
    of_node_put(node);
    if (IS_ERR(clk))
        return PTR_ERR(clk);

    pwm_input = clk;
    pr_info("tanix_sdio_overlay: PWM_E before = %lu Hz\n", clk_get_rate(clk));
    ret = clk_set_max_rate(clk, 24000000);
    if (ret)
        return ret;

    node = of_find_node_by_path("/sdio-pwrseq");
    if (!node)
        return -ENODEV;
    clk = of_clk_get_by_name(node, "ext_clock");
    of_node_put(node);
    if (IS_ERR(clk))
        return PTR_ERR(clk);

    ret = clk_prepare_enable(clk);
    if (ret) {
        clk_put(clk);
        return ret;
    }
    sdio_ref = clk;
    pr_info("tanix_sdio_overlay: PWM_E = %lu Hz; SDIO reference = %lu Hz\n",
            clk_get_rate(pwm_input), clk_get_rate(sdio_ref));
    return 0;
}

static int __init tanix_sdio_overlay_init(void)
{
    int ret;

    if (cap_pwm) {
        ret = start_reference_clock();
        if (ret)
            goto err_clock;
    }

    if (!apply_delay)
        return 0;

    ret = of_overlay_fdt_apply(overlay_blob, sizeof(overlay_blob),
                               &overlay_id, NULL);
    if (!ret)
        return 0;
    if (overlay_id)
        of_overlay_remove(&overlay_id);
err_clock:
    stop_reference_clock();
    return ret;
}

static void __exit tanix_sdio_overlay_exit(void)
{
    if (apply_delay) {
        int ret = of_overlay_remove(&overlay_id);

        if (ret)
            pr_err("tanix_sdio_overlay: removal failed: %d\n", ret);
    }
    stop_reference_clock();
}

module_init(tanix_sdio_overlay_init);
module_exit(tanix_sdio_overlay_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Temporary Tanix W2 SDIO diagnostic device tree overlay");
